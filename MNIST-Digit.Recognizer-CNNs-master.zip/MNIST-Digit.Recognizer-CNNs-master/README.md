# MNIST-Digit.Recognizer-CNNs
Implementation of CNN to recognize hand written digits (MNIST) running for 10 epochs. Accuracy: 98.99%

## Towards Data Science Blog
[A Comprehensive Guide To Convolutional Neural Networks-The ELI5 Way](https://towardsdatascience.com/a-comprehensive-guide-to-convolutional-neural-networks-the-eli5-way-3bd2b1164a53)
